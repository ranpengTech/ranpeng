//import  * as Phaser  from '/node_modules/phaser/dist/phaser.esm.js'
import Phaser from 'phaser';

class TetrisGame extends Phaser.Scene {
  constructor() {
    super({ key: 'TetrisGame' });
  }

  preload() {
    // 加载资源
  }

  create() {
    // 初始化游戏
    this.grid = [];
    const gridSize = 20;
    const gridWidth = 15;
    const gridHeight = 30;

    for (let row = 0; row < gridHeight; row++) {
      this.grid[row] = [];
      for (let col = 0; col < gridWidth; col++) {
        this.grid[row][col] = 0;
      }
    }

    this.createGridGraphics(gridSize);
    this.currentTetromino = this.createTetromino();
    this.inputKeyboard();

    this.score = 0;
    this.scoreText = this.add.text(10, 10, `Score: ${this.score}`, { fontSize: '20px', fill: '#fff' });

    this.lastFallTime = 0;
  }

  createGridGraphics(gridSize) {
    this.gridGraphics = this.add.graphics();
    for (let row = 0; row < this.grid.length; row++) {
      for (let col = 0; col < this.grid[row].length; col++) {
        this.gridGraphics.lineStyle(1, 0x00ff00, 1);
        this.gridGraphics.strokeRect(col * gridSize, row * gridSize, gridSize, gridSize);
      }
    }
  }

  createTetromino() {
    const shapeIndex = Math.floor(Math.random() * SHAPES.length);
    const shape = SHAPES[shapeIndex];
    const color = COLORS[shapeIndex];
    return new Tetromino(this, shape, color, 3 * 20, 0);
  }

  inputKeyboard() {
    this.input.keyboard.addKey("LEFT").on("down", (e) => {
      this.currentTetromino.move(-20, 0);
    });
    this.input.keyboard.addKey("RIGHT").on("down", (e) => {
      this.currentTetromino.move(20, 0);
    });
    this.input.keyboard.addKey("UP").on("down", (e) => {
      this.currentTetromino.rotate();
    });
    this.input.keyboard.addKey("DOWN").on("down", (e) => {
      this.currentTetromino.move(0, 20);
    });
  }

  update(time, delta) {
    // 游戏逻辑更新
    if (time - this.lastFallTime > 1000) {
      this.currentTetromino.move(0, 20);
      this.lastFallTime = time;
    }
    
    if (!this.currentTetromino.canMove(this.currentTetromino.shape)) {
      this.currentTetromino.lock();
      this.currentTetromino = this.createTetromino();
    }
    
    if (this.currentTetromino.y <= 0 && !this.currentTetromino.canMove(this.currentTetromino.shape)) {
      this.gameOver();
    }
  }

  clearLines() {
    let linesCleared = 0;
    for (let row = 0; row < this.grid.length; row++) {
      if (this.grid[row].every(cell => cell !== 0)) {
        for (let col = 0; col < 15; col++)
          this.grid[row][col].destroy();
        this.grid.splice(row, 1);
        this.grid.unshift(Array(15).fill(0));
        linesCleared++;
      }
    }

    if (linesCleared > 0) {
      this.score += linesCleared * 100;
      this.updateScore();
      for (let row = 0; row < this.grid.length; row++) {
        for (let col = 0; col < this.grid[row].length; col++) {
          if (this.grid[row][col] !== 0) {
            this.grid[row][col].x = col * 20;
            this.grid[row][col].y = row * 20;
          }
        }
      }
    }
  }

  updateScore() {
    this.scoreText.setText(`Score: ${this.score}`);
  }

  gameOver() {
    this.scene.pause();
    this.add.text(100, 300, 'Game Over', { fontSize: '40px', fill: '#ff0000' });
  }
}

const SHAPES = [
  [[1, 1, 1, 1]], // I 形
  [[1, 1, 1], [0, 1, 0]], // T 形
  [[1, 1, 1], [1, 0, 0]], // L 形
  [[1, 1, 1], [0, 0, 1]], // J 形
  [[1, 1], [1, 1]], // O 形
  [[0, 1, 1], [1, 1, 0]], // S 形
  [[1, 1, 0], [0, 1, 1]] // Z 形
];

const COLORS = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFFFFF'];
class Tetromino {
  constructor(scene, shape, color, x, y) {
    this.scene = scene;
    this.shape = shape;
    this.color = color;
    this.x = x;
    this.y = y;
    this.createBlocks();
  }

  createBlocks() {
    this.blocks = [];
    for (let row = 0; row < this.shape.length; row++) {
      for (let col = 0; col < this.shape[row].length; col++) {
        if (this.shape[row][col] === 1) {
          const block = this.scene.add.rectangle(
            this.x + col * 20,
            this.y + row * 20,
            20, 20,
            Phaser.Display.Color.ValueToColor(this.color).color
          );
          block.setOrigin(0);
          this.blocks.push(block);
        }
      }
    }
  }

  move(dx, dy) {
    this.x += dx;
    this.y += dy;
    if (dx != 0 && !this.canMove(this.shape)) {
      this.x -= dx;
      this.y -= dy;
      return;
    }
    this.updatePosition(dx, dy);
  }

  updatePosition(dx, dy) {
    for (let block of this.blocks) {
      block.x = block.x += dx;
      block.y = block.y += dy;
    }
  }

  clearBlocks() {
    for (let block of this.blocks) {
      block.destroy();
    }
  }

  rotate() {
    const newShape = this.rotateShape(this.shape);
    if (this.canMove(newShape)) {
      this.shape = newShape;
      this.clearBlocks();
      this.createBlocks();
    }
  }

  rotateShape(shape) {
    const newShape = [];
    for (let col = 0; col < shape[0].length; col++) {
      newShape[col] = [];
      for (let row = 0; row < shape.length; row++) {
        newShape[col][row] = shape[shape.length - 1 - row][col];
      }
    }
    return newShape;
  }

  canMove(shape) {
    for (let row = 0; row < shape.length; row++) {
      for (let col = 0; col < shape[row].length; col++) {
        if (shape[row][col] === 1) {
          const gridRow = Math.floor((this.y + row * 20) / 20);
          const gridColumn = Math.floor((this.x + col * 20) / 20);
          if (gridRow < 0 || gridRow >= 29 || gridColumn < 0 || gridColumn >= 15 || this.scene.grid[gridRow+1][gridColumn] !== 0) {
            return false;
          }
        }
      }
    }
    return true;
  }

  lock() {
    for (let row = 0; row < this.shape.length; row++) {
      for (let col = 0; col < this.shape[row].length; col++) {
        if (this.shape[row][col] === 1) {
          const gridRow = Math.floor((this.y + row * 20) / 20);
          const gridColumn = Math.floor((this.x + col * 20) / 20);
          this.scene.grid[gridRow][gridColumn] = this.blocks.shift();
        }
      }
    }
    this.scene.clearLines();
  }
}

var config = {
  type: Phaser.AUTO,
  width: 300,
  height: 600,
  parent: "container",
  backgroundColor: '#001',
  scene: [TetrisGame]
};

var game = new Phaser.Game(config);

